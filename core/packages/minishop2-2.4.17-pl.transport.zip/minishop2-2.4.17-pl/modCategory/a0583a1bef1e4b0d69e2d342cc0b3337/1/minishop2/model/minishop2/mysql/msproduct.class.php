<?php
require_once (dirname(__DIR__) . '/msproduct.class.php');
class msProduct_mysql extends msProduct {}