<?php
require_once (dirname(__DIR__) . '/msproductlink.class.php');
class msProductLink_mysql extends msProductLink {}