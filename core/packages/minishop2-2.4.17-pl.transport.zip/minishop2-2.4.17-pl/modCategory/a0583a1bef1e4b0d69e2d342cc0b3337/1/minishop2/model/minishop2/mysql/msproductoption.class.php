<?php
require_once (dirname(__DIR__) . '/msproductoption.class.php');
class msProductOption_mysql extends msProductOption {}